# Copyright (c) 2025, isfak and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestArticle(FrappeTestCase):
	pass
