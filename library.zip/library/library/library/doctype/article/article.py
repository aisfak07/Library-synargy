# Copyright (c) 2025, isfak and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class Article(Document):
	pass
