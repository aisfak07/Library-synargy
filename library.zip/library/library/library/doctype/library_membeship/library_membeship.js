// Copyright (c) 2025, isfak and contributors
// For license information, please see license.txt

frappe.ui.form.on("Library Membeship", {
	refresh(frm) {
        frappe.msgprint("Welcome Isfak Ahmed 1");
	},
});
